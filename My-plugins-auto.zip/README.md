# My Aliucord Plugins

### [BlockThemCalls](https://github.com/RazerTexz/My-plugins/raw/builds/BlockThemCalls.zip)
Adds a way to block calls from other users.
Works with group chat(s) too.

### [BetterFontScale](https://github.com/RazerTexz/My-plugins/raw/builds/BetterFontScale.zip)
Better font scale (check plugin settings).